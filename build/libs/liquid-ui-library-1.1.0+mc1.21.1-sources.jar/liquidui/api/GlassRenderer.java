package liquidui.api;

import com.mojang.blaze3d.systems.RenderSystem;
import liquidui.LiquidUiLibrary;
import net.fabricmc.fabric.api.client.rendering.v1.CoreShaderRegistrationCallback;
import net.minecraft.class_156;
import net.minecraft.class_276;
import net.minecraft.class_286;
import net.minecraft.class_287;
import net.minecraft.class_289;
import net.minecraft.class_290;
import net.minecraft.class_293;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_5944;
import net.minecraft.class_6367;
import net.minecraft.class_757;
import org.joml.Matrix4f;
import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GL30;

/** Captures the backdrop once per frame; never reads from the target being drawn to. */
public final class GlassRenderer {
    private static class_5944 shader;
    private static class_6367 backdrop;

    private GlassRenderer() {}

    public static void initialize() {
        CoreShaderRegistrationCallback.EVENT.register(context -> context.register(
                LiquidUiLibrary.id("liquid_glass"), class_290.field_1585,
                loaded -> shader = loaded));
    }

    public static void capture(class_332 graphics) {
        graphics.method_51452();
        class_276 main = class_310.method_1551().method_1522();
        // Keep the captured backdrop at native framebuffer resolution. A
        // downscaled copy produced visible texel columns on large displays;
        // the shader itself provides the blur without stretching pixels.
        int w = Math.max(1, main.field_1482);
        int h = Math.max(1, main.field_1481);
        if (backdrop == null || backdrop.field_1482 != w || backdrop.field_1481 != h) {
            if (backdrop != null) backdrop.method_1238();
            backdrop = new class_6367(w, h, false, class_310.field_1703);
            backdrop.method_58226(GL11.GL_LINEAR);
        }
        GL30.glBindFramebuffer(GL30.GL_READ_FRAMEBUFFER, main.field_1476);
        GL30.glBindFramebuffer(GL30.GL_DRAW_FRAMEBUFFER, backdrop.field_1476);
        GL30.glBlitFramebuffer(0, 0, main.field_1482, main.field_1481, 0, 0, w, h,
                GL11.GL_COLOR_BUFFER_BIT, GL11.GL_LINEAR);
        main.method_1235(true);
    }

    public static void draw(class_332 graphics, int x, int y, int w, int h,
                            float opacity, boolean highlighted, boolean active) {
        draw(graphics, x, y, w, h, opacity, highlighted, active, false);
    }

    public static void drawDanger(class_332 graphics, int x, int y, int w, int h,
                                  float opacity, boolean highlighted) {
        draw(graphics, x, y, w, h, opacity, highlighted, true, true,
                x + w * 0.5F, y + h * 0.5F, 0F, false, 1F);
    }

    public static void drawDangerInteractive(class_332 graphics, int x, int y, int w, int h,
                                             float opacity, boolean highlighted,
                                             float mouseX, float mouseY, float hoverAmount) {
        draw(graphics, x, y, w, h, opacity, highlighted, true, true,
                mouseX, mouseY, hoverAmount, false, 1F);
    }

    public static void drawInteractive(class_332 graphics, int x, int y, int w, int h,
                                       float opacity, boolean highlighted, boolean active,
                                       float mouseX, float mouseY, float hoverAmount) {
        draw(graphics, x, y, w, h, opacity, highlighted, active, false,
                mouseX, mouseY, hoverAmount, false, 1F);
    }

    public static void drawRevealingInteractive(class_332 graphics, int x, int y, int w, int h,
                                                float opacity, boolean highlighted, boolean active,
                                                float mouseX, float mouseY, float hoverAmount,
                                                float revealAmount) {
        draw(graphics, x, y, w, h, opacity, highlighted, active, false,
                mouseX, mouseY, hoverAmount, false,
                Math.max(0F, Math.min(1F, revealAmount)));
    }

    public static void drawIconOverlayInteractive(class_332 graphics, int x, int y, int w, int h,
                                                  float opacity, boolean highlighted,
                                                  float mouseX, float mouseY, float hoverAmount) {
        draw(graphics, x, y, w, h, opacity, highlighted, true, false,
                mouseX, mouseY, hoverAmount, true, 1F);
    }

    /** Draws a rounded image using exactly the same lift and pointer tilt as a glass tile. */
    public static void drawRoundedTextureInteractive(class_332 graphics, class_2960 texture,
                                                     int x, int y, int w, int h, float opacity,
                                                     float mouseX, float mouseY, float hoverAmount) {
        if (w <= 0 || h <= 0) return;
        graphics.method_51452();
        class_5944 previous = RenderSystem.getShader();
        RenderSystem.disableDepthTest();
        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.setShader(class_757::method_34542);
        RenderSystem.setShaderTexture(0, texture);
        RenderSystem.setShaderColor(1F, 1F, 1F, opacity);

        float pointerX = Math.max(-1F, Math.min(1F, (mouseX - x) / Math.max(1F, w) * 2F - 1F));
        float pointerY = Math.max(-1F, Math.min(1F, (mouseY - y) / Math.max(1F, h) * 2F - 1F));
        float tiltX = pointerX * hoverAmount;
        float tiltY = pointerY * hoverAmount;
        float visibleV = Math.min(1F, h / (float) w);
        float topV = (1F - visibleV) * 0.5F;
        // Match the exact radius used by liquid_glass.fsh. Keep the image two
        // GUI pixels inside the outline so texture texels cannot leak past it
        // while the plate is tilted or scaled.
        int edgeInset = 2;
        int radius = Math.min(18, Math.round(h * 0.30F));
        int innerRadius = Math.max(1, radius - edgeInset);
        int innerHeight = Math.max(1, h - edgeInset * 2);
        Matrix4f matrix = graphics.method_51448().method_23760().method_23761();
        class_287 buffer = class_289.method_1348().method_60827(class_293.class_5596.field_27382, class_290.field_1585);
        for (int row = edgeInset; row < h - edgeInset; row++) {
            int innerRow = row - edgeInset;
            float cornerY = innerRow < innerRadius ? innerRadius - innerRow - 0.5F
                    : innerRow >= innerHeight - innerRadius
                    ? innerRow - (innerHeight - innerRadius) + 0.5F : 0F;
            int inset = cornerY > 0F
                    ? Math.max(0, (int) Math.ceil(innerRadius
                    - Math.sqrt(innerRadius * innerRadius - cornerY * cornerY))) : 0;
            float left = edgeInset + inset;
            float right = w - edgeInset - inset;
            if (right <= left) continue;
            float u0 = left / w;
            float u1 = right / w;
            float v0 = topV + row * visibleV / h;
            float v1 = topV + (row + 1F) * visibleV / h;
            addTiltedTextureVertex(buffer, matrix, x, y, w, h,
                    left, row + 1F, u0, v1, tiltX, tiltY);
            addTiltedTextureVertex(buffer, matrix, x, y, w, h,
                    right, row + 1F, u1, v1, tiltX, tiltY);
            addTiltedTextureVertex(buffer, matrix, x, y, w, h,
                    right, row, u1, v0, tiltX, tiltY);
            addTiltedTextureVertex(buffer, matrix, x, y, w, h,
                    left, row, u0, v0, tiltX, tiltY);
        }
        class_286.method_43433(buffer.method_60800());
        RenderSystem.setShaderColor(1F, 1F, 1F, 1F);
        RenderSystem.setShader(() -> previous);
        RenderSystem.enableDepthTest();
        RenderSystem.disableBlend();
    }

    private static void draw(class_332 graphics, int x, int y, int w, int h,
                             float opacity, boolean highlighted, boolean active, boolean danger) {
        draw(graphics, x, y, w, h, opacity, highlighted, active, danger,
                x + w * 0.5F, y + h * 0.5F, 0F, false, 1F);
    }

    private static void draw(class_332 graphics, int x, int y, int w, int h,
                             float opacity, boolean highlighted, boolean active, boolean danger,
                             float mouseX, float mouseY, float hoverAmount, boolean iconMode,
                             float revealAmount) {
        if (shader == null || backdrop == null) return;
        graphics.method_51452();
        class_276 main = class_310.method_1551().method_1522();
        float scale = (float) class_310.method_1551().method_22683().method_4495();
        class_5944 previous = RenderSystem.getShader();
        RenderSystem.disableDepthTest();
        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.setShader(() -> shader);
        RenderSystem.setShaderTexture(0, backdrop.method_30277());
        shader.method_35785("FrameSize").method_1255((float) main.field_1482, (float) main.field_1481);
        shader.method_35785("RectSize").method_1255((float) w, (float) h);
        shader.method_35785("GuiScale").method_1251(scale);
        shader.method_35785("Opacity").method_1251(opacity);
        shader.method_35785("Highlight").method_1251(highlighted ? 1F : 0F);
        shader.method_35785("Enabled").method_1251(active ? 1F : 0F);
        shader.method_35785("Danger").method_1251(danger ? 1F : 0F);
        shader.method_35785("IconMode").method_1251(iconMode ? 1F : 0F);
        shader.method_35785("Pointer").method_1255(mouseX - x, mouseY - y);
        shader.method_35785("Hover").method_1251(hoverAmount);
        shader.method_35785("Reveal").method_1251(revealAmount);
        shader.method_35785("Time").method_1251((class_156.method_658() % 100000L) / 1000F);
        Matrix4f matrix = graphics.method_51448().method_23760().method_23761();
        float pad = 5;
        float pointerX = Math.max(-1F, Math.min(1F, (mouseX - x) / Math.max(1F, w) * 2F - 1F));
        float pointerY = Math.max(-1F, Math.min(1F, (mouseY - y) / Math.max(1F, h) * 2F - 1F));
        float tiltX = pointerX * hoverAmount;
        float tiltY = pointerY * hoverAmount;
        class_287 buffer = class_289.method_1348().method_60827(class_293.class_5596.field_27382, class_290.field_1585);
        addTiltedVertex(buffer, matrix, x, y, w, h, -pad, h + pad, tiltX, tiltY);
        addTiltedVertex(buffer, matrix, x, y, w, h, w + pad, h + pad, tiltX, tiltY);
        addTiltedVertex(buffer, matrix, x, y, w, h, w + pad, -pad, tiltX, tiltY);
        addTiltedVertex(buffer, matrix, x, y, w, h, -pad, -pad, tiltX, tiltY);
        class_286.method_43433(buffer.method_60800());
        RenderSystem.setShader(() -> previous);
        RenderSystem.enableDepthTest();
        RenderSystem.disableBlend();
    }

    private static void addTiltedVertex(class_287 buffer, Matrix4f matrix,
                                        int x, int y, int w, int h, float localX, float localY,
                                        float tiltX, float tiltY) {
        float nx = (localX - w * 0.5F) / Math.max(1F, w * 0.5F);
        float ny = (localY - h * 0.5F) / Math.max(1F, h * 0.5F);
        float perspective = 1F + (tiltX * nx + tiltY * ny) * 0.026F;
        float px = x + w * 0.5F + (localX - w * 0.5F) * perspective + tiltX * 1.4F;
        float py = y + h * 0.5F + (localY - h * 0.5F) * perspective + tiltY * 1.0F;
        buffer.method_22918(matrix, px, py, 0).method_22913(localX, localY);
    }

    private static void addTiltedTextureVertex(class_287 buffer, Matrix4f matrix,
                                               int x, int y, int w, int h,
                                               float localX, float localY, float u, float v,
                                               float tiltX, float tiltY) {
        float nx = (localX - w * 0.5F) / Math.max(1F, w * 0.5F);
        float ny = (localY - h * 0.5F) / Math.max(1F, h * 0.5F);
        float perspective = 1F + (tiltX * nx + tiltY * ny) * 0.026F;
        float px = x + w * 0.5F + (localX - w * 0.5F) * perspective + tiltX * 1.4F;
        float py = y + h * 0.5F + (localY - h * 0.5F) * perspective + tiltY * 1.0F;
        buffer.method_22918(matrix, px, py, 0).method_22913(u, v);
    }

    public static void release() {
        if (backdrop != null) {
            backdrop.method_1238();
            backdrop = null;
        }
        SmoothLabel.release();
    }
}
