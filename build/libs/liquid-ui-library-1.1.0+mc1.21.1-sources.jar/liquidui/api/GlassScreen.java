package liquidui.api;

import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_437;

/** Base for extension screens. Background capture always precedes glass widgets. */
public abstract class GlassScreen extends class_437 {
    private final class_437 parent;

    protected GlassScreen(class_2561 title, class_437 parent) {
        super(title);
        this.parent = parent;
    }

    /** Override to draw your background; do not draw glass controls here. */
    protected void renderGlassBackground(class_332 graphics, int mouseX, int mouseY,
                                         float partialTick) {
        method_25420(graphics, mouseX, mouseY, partialTick);
    }

    /** Override for labels and decorations drawn above the background. */
    protected void renderGlassContent(class_332 graphics, int mouseX, int mouseY,
                                      float partialTick) {
        graphics.method_27534(field_22793, field_22785, field_22789 / 2, 20, 0xFFFFFF);
    }

    @Override
    public final void method_25394(class_332 graphics, int mouseX, int mouseY, float partialTick) {
        renderGlassBackground(graphics, mouseX, mouseY, partialTick);
        GlassRenderer.capture(graphics);
        renderGlassContent(graphics, mouseX, mouseY, partialTick);
        super.method_25394(graphics, mouseX, mouseY, partialTick);
    }

    @Override
    public void method_25419() {
        field_22787.method_1507(parent);
    }
}
