package liquidui.api;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.function.Consumer;
import java.util.function.Function;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_4185;
import net.minecraft.class_437;

/** Register on the client initialization thread; hosts create fresh widgets per screen. */
public final class LiquidMenus {
    private static final Map<class_2960, Entry> CODE_ENTRIES = new LinkedHashMap<>();
    private static final Map<class_2960, Entry> DATA_ENTRIES = new LinkedHashMap<>();

    private LiquidMenus() {}

    /** Register an action. IDs must be unique and namespaced by the extension mod. */
    public static void register(class_2960 id, class_2561 label, int order,
                                Consumer<class_437> action) {
        Objects.requireNonNull(id, "id");
        Objects.requireNonNull(label, "label");
        Objects.requireNonNull(action, "action");
        if (CODE_ENTRIES.containsKey(id)) {
            throw new IllegalArgumentException("Liquid UI menu entry already registered: " + id);
        }
        CODE_ENTRIES.put(id, new Entry(label.method_27661(), order, action));
    }

    /** The factory receives the parent screen, for Back/Escape navigation. */
    public static void registerScreen(class_2960 id, class_2561 label, int order,
                                       Function<class_437, class_437> factory) {
        Objects.requireNonNull(factory, "factory");
        register(id, label, order, parent -> class_310.method_1551().method_1507(
                Objects.requireNonNull(factory.apply(parent), "screen factory result")));
    }

    /** Host API: add these fresh widgets once per init, then apply your layout. */
    public static List<class_4185> createButtons(class_437 parent) {
        Objects.requireNonNull(parent, "parent");
        List<class_4185> buttons = new ArrayList<>();
        List<Entry> entries = new ArrayList<>(CODE_ENTRIES.values());
        entries.addAll(DATA_ENTRIES.values());
        entries.stream().sorted(Comparator.comparingInt(Entry::order)).forEach(entry -> {
            class_4185 action = class_4185.method_46430(entry.label().method_27661(), button -> entry.action().accept(parent))
                    .method_46434(0, 0, 132, 78).method_46431();
            buttons.add(new RoundedMenuButton(action, 0, 0, 132, 78));
        });
        return List.copyOf(buttons);
    }

    static void replaceDataEntries(Map<class_2960, DataEntry> replacements) {
        DATA_ENTRIES.clear();
        replacements.forEach((id, entry) -> DATA_ENTRIES.put(id,
                new Entry(entry.label().method_27661(), entry.order(), entry.action())));
    }

    static record DataEntry(class_2561 label, int order, Consumer<class_437> action) {}

    private record Entry(class_2561 label, int order, Consumer<class_437> action) {}
}
