package liquidui.api;

import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_4185;

/** Standalone liquid-glass button for custom Fabric screens. */
public final class GlassButton extends class_4185 {
    private final LiquidTheme theme;
    private float hoverAmount;
    private float focusAmount;

    private GlassButton(int x, int y, int width, int height, class_2561 message,
                        class_4241 onPress, LiquidTheme theme) {
        super(x, y, width, height, message, onPress, field_40754);
        this.theme = theme;
    }

    public static Builder glassBuilder(class_2561 message, class_4241 onPress) {
        return new Builder(message, onPress);
    }

    @Override
    protected void method_48579(class_332 graphics, int mouseX, int mouseY, float partialTick) {
        float hoverTarget = field_22763 && method_49606() ? 1F : 0F;
        hoverAmount += (hoverTarget - hoverAmount) * theme.animationSpeed();
        float focusTarget = field_22763 && method_25370() && !method_49606() ? 1F : 0F;
        focusAmount += (focusTarget - focusAmount) * theme.animationSpeed();

        float hoverEase = easeOut(hoverAmount);
        int grow = Math.round(easeOut(focusAmount) * theme.focusGrowth());
        int drawX = method_46426() - grow;
        int drawY = method_46427() - Math.round(hoverEase * theme.hoverLift()) - grow;
        int drawWidth = field_22758 + grow * 2;
        int drawHeight = field_22759 + grow * 2;
        GlassRenderer.drawInteractive(graphics, drawX, drawY, drawWidth, drawHeight,
                field_22765 * theme.opacity(), field_22763 && method_25367(), field_22763,
                mouseX, mouseY, hoverAmount);
        SmoothLabel.draw(graphics, method_25369().getString(), drawX, drawY,
                drawWidth, drawHeight, field_22765, field_22763, hoverAmount);
    }

    private static float easeOut(float value) {
        return 1F - (float) Math.pow(1F - value, 3);
    }

    public static final class Builder {
        private final class_2561 message;
        private final class_4241 onPress;
        private int x;
        private int y;
        private int width = 150;
        private int height = 40;
        private LiquidTheme theme = LiquidTheme.DEFAULT;

        private Builder(class_2561 message, class_4241 onPress) {
            this.message = message;
            this.onPress = onPress;
        }

        public Builder position(int x, int y) {
            this.x = x;
            this.y = y;
            return this;
        }

        public Builder size(int width, int height) {
            this.width = width;
            this.height = height;
            return this;
        }

        public Builder theme(LiquidTheme theme) {
            this.theme = theme;
            return this;
        }

        public GlassButton build() {
            return new GlassButton(x, y, width, height, message, onPress, theme);
        }
    }
}
