package liquidui.api;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import java.io.BufferedReader;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import liquidui.LiquidUiLibrary;
import net.fabricmc.fabric.api.resource.ResourceManagerHelper;
import net.fabricmc.fabric.api.resource.SimpleSynchronousResourceReloadListener;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_3264;
import net.minecraft.class_3298;
import net.minecraft.class_3300;
import net.minecraft.class_332;
import net.minecraft.class_426;
import net.minecraft.class_429;
import net.minecraft.class_437;
import net.minecraft.class_442;
import net.minecraft.class_500;
import net.minecraft.class_526;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/** Loads no-code Liquid UI screens from assets/&lt;namespace&gt;/liquid_ui/extensions/*.json. */
public final class LiquidExtensionLoader {
    private static final Logger LOGGER = LoggerFactory.getLogger("liquid-ui-extensions");
    private static final class_2960 LISTENER_ID =
            new class_2960(LiquidUiLibrary.MOD_ID, "extensions");
    private static final Map<class_2960, ScreenDefinition> SCREENS = new LinkedHashMap<>();
    private static boolean initialized;

    private LiquidExtensionLoader() {}

    public static synchronized void initialize() {
        if (initialized) return;
        initialized = true;
        ResourceManagerHelper.get(class_3264.field_14188).registerReloadListener(new Listener());
    }

    private static void reload(class_3300 manager) {
        Map<class_2960, ScreenDefinition> loaded = new LinkedHashMap<>();
        manager.method_14488("liquid_ui/extensions", id -> id.method_12832().endsWith(".json"))
                .forEach((resourceId, resource) -> read(resourceId, resource, loaded));
        SCREENS.clear();
        SCREENS.putAll(loaded);

        Map<class_2960, LiquidMenus.DataEntry> menuEntries = new LinkedHashMap<>();
        loaded.forEach((id, definition) -> {
            if (definition.menuLabel() == null || definition.menuLabel().isBlank()) return;
            menuEntries.put(id, new LiquidMenus.DataEntry(class_2561.method_43470(definition.menuLabel()),
                    definition.order(), parent -> class_310.method_1551().method_1507(
                    new DataScreen(parent, id, definition))));
        });
        LiquidMenus.replaceDataEntries(menuEntries);
        LOGGER.info("Loaded {} Liquid UI no-code screen(s)", loaded.size());
    }

    private static void read(class_2960 resourceId, class_3298 resource,
                             Map<class_2960, ScreenDefinition> loaded) {
        try (BufferedReader reader = resource.method_43039()) {
            JsonObject root = JsonParser.parseReader(reader).getAsJsonObject();
            class_2960 id = new class_2960(requiredString(root, "id"));
            String title = string(root, "title", id.method_12832());
            JsonObject menu = root.has("menu") && root.get("menu").isJsonObject()
                    ? root.getAsJsonObject("menu") : new JsonObject();
            String menuLabel = string(menu, "label", title);
            int order = integer(menu, "order", 100);
            List<ButtonDefinition> buttons = new ArrayList<>();
            JsonArray elements = root.has("elements") && root.get("elements").isJsonArray()
                    ? root.getAsJsonArray("elements") : new JsonArray();
            for (JsonElement element : elements) {
                if (!element.isJsonObject()) continue;
                JsonObject object = element.getAsJsonObject();
                if (!"button".equalsIgnoreCase(string(object, "type", "button"))) continue;
                JsonObject action = object.has("action") && object.get("action").isJsonObject()
                        ? object.getAsJsonObject("action") : new JsonObject();
                buttons.add(new ButtonDefinition(string(object, "text", "Button"),
                        integer(object, "x", -100), integer(object, "y", 0),
                        Math.max(40, integer(object, "width", 200)),
                        Math.max(20, integer(object, "height", 48)),
                        string(action, "type", "back"), string(action, "target", "")));
            }
            ScreenDefinition previous = loaded.put(id,
                    new ScreenDefinition(title, menuLabel, order, List.copyOf(buttons)));
            if (previous != null) LOGGER.warn("Duplicate Liquid UI screen id {}, last resource wins", id);
        } catch (Exception exception) {
            LOGGER.error("Could not load Liquid UI extension {}", resourceId, exception);
        }
    }

    private static String requiredString(JsonObject object, String name) {
        if (!object.has(name) || !object.get(name).isJsonPrimitive()) {
            throw new IllegalArgumentException("Missing string property: " + name);
        }
        return object.get(name).getAsString();
    }

    private static String string(JsonObject object, String name, String fallback) {
        return object.has(name) && object.get(name).isJsonPrimitive()
                ? object.get(name).getAsString() : fallback;
    }

    private static int integer(JsonObject object, String name, int fallback) {
        try {
            return object.has(name) ? object.get(name).getAsInt() : fallback;
        } catch (RuntimeException ignored) {
            return fallback;
        }
    }

    private record ScreenDefinition(String title, String menuLabel, int order,
                                    List<ButtonDefinition> buttons) {}

    private record ButtonDefinition(String text, int x, int y, int width, int height,
                                    String action, String target) {}

    private static final class DataScreen extends GlassScreen {
        private final class_2960 definitionId;
        private final ScreenDefinition definition;

        private DataScreen(class_437 parent, class_2960 definitionId, ScreenDefinition definition) {
            super(class_2561.method_43470(definition.title()), parent);
            this.definitionId = definitionId;
            this.definition = definition;
        }

        @Override
        protected void method_25426() {
            LiquidTheme theme = LiquidTheme.DEFAULT;
            for (ButtonDefinition button : definition.buttons()) {
                int x = field_22789 / 2 + button.x();
                int y = field_22790 / 2 + button.y();
                method_37063(GlassButton.glassBuilder(class_2561.method_43470(button.text()),
                        ignored -> perform(button)).position(x, y)
                        .size(button.width(), button.height()).theme(theme).build());
            }
        }

        @Override
        protected void renderGlassContent(class_332 graphics, int mouseX, int mouseY,
                                          float partialTick) {
            graphics.method_27534(field_22793, field_22785, field_22789 / 2, 20, 0xFFFFFF);
        }

        private void perform(ButtonDefinition button) {
            String action = button.action().toLowerCase(Locale.ROOT);
            switch (action) {
                case "back" -> method_25419();
                case "close" -> field_22787.method_1507(null);
                case "main_menu" -> field_22787.method_1507(new class_442());
                case "options" -> field_22787.method_1507(new class_429(this, field_22787.field_1690));
                case "language" -> field_22787.method_1507(new class_426(this, field_22787.field_1690,
                        field_22787.method_1526()));
                case "singleplayer" -> field_22787.method_1507(new class_526(this));
                case "multiplayer" -> field_22787.method_1507(new class_500(this));
                case "open_screen" -> openTarget(button.target());
                default -> LOGGER.warn("Unknown action '{}' on screen {}", button.action(), definitionId);
            }
        }

        private void openTarget(String target) {
            try {
                class_2960 targetId = new class_2960(target);
                ScreenDefinition targetDefinition = SCREENS.get(targetId);
                if (targetDefinition == null) {
                    LOGGER.warn("Unknown Liquid UI target screen {}", targetId);
                    return;
                }
                field_22787.method_1507(new DataScreen(this, targetId, targetDefinition));
            } catch (RuntimeException exception) {
                LOGGER.warn("Invalid Liquid UI target '{}'", target);
            }
        }
    }

    private static final class Listener implements SimpleSynchronousResourceReloadListener {
        @Override
        public class_2960 getFabricId() {
            return LISTENER_ID;
        }

        @Override
        public void method_14491(class_3300 manager) {
            LiquidExtensionLoader.reload(manager);
        }
    }
}
