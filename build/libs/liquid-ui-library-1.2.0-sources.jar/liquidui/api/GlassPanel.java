package liquidui.api;

import net.minecraft.class_332;

/** Helpers for drawing non-interactive glass panels in a custom screen. */
public final class GlassPanel {
    private GlassPanel() {
    }

    public static void capture(class_332 graphics) {
        GlassRenderer.capture(graphics);
    }

    public static void draw(class_332 graphics, int x, int y, int width, int height,
                            float opacity) {
        GlassRenderer.draw(graphics, x, y, width, height, opacity, false, true);
    }
}
