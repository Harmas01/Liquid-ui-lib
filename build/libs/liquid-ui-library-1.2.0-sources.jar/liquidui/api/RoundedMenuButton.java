package liquidui.api;

import net.minecraft.class_156;
import net.minecraft.class_332;
import net.minecraft.class_4185;

/** Smooth frosted-glass controls, retaining vanilla actions and keyboard navigation. */
public final class RoundedMenuButton extends class_4185 {
    private final class_4185 original;
    private float hoverLift;
    private float focusScale;
    private long entranceStartedAt = -1L;
    private long entranceDelayMs;

    public RoundedMenuButton(class_4185 original, int x, int y, int width, int height) {
        this(original, x, y, width, height, button -> original.method_25306());
    }

    public RoundedMenuButton(class_4185 original, int x, int y, int width, int height, class_4241 onPress) {
        super(x, y, width, height, original.method_25369(), onPress, field_40754);
        this.original = original;
        field_22763 = original.field_22763;
        field_22764 = original.field_22764;
        method_47400(original.method_51254());
    }

    /** Starts a soft entrance animation after the supplied delay. */
    public RoundedMenuButton withEntranceDelay(long delayMs) {
        entranceDelayMs = Math.max(0L, delayMs);
        entranceStartedAt = class_156.method_658();
        return this;
    }

    private float entranceProgress() {
        if (entranceStartedAt < 0L) return 1F;
        float progress = (class_156.method_658() - entranceStartedAt - entranceDelayMs) / 500F;
        progress = Math.max(0F, Math.min(1F, progress));
        // A sine curve starts visibly earlier than smootherstep while keeping
        // zero velocity at both ends, avoiding a late opacity jump.
        return 0.5F - (float) Math.cos(progress * Math.PI) * 0.5F;
    }

    @Override
    public boolean method_25405(double mouseX, double mouseY) {
        return entranceProgress() > 0.9F && field_22763 && field_22764
                && mouseX >= method_46426() - 3 && mouseX < method_46426() + field_22758 + 3
                && mouseY >= method_46427() - 8 && mouseY < method_46427() + field_22759 + 3;
    }

    @Override
    protected void method_48579(class_332 graphics, int mouseX, int mouseY, float partialTick) {
        field_22763 = original.field_22763;
        field_22764 = original.field_22764;
        method_25355(original.method_25369());
        if (field_22765 <= 0.02F) return;
        float entrance = entranceProgress();
        float target = field_22763 && method_49606() ? 1F : 0F;
        hoverLift += (target - hoverLift) * 0.22F;
        if (Math.abs(target - hoverLift) < 0.002F) hoverLift = target;
        float focusTarget = field_22763 && method_25370() && !method_49606() ? 1F : 0F;
        focusScale += (focusTarget - focusScale) * 0.20F;
        if (Math.abs(focusTarget - focusScale) < 0.002F) focusScale = focusTarget;
        float eased = 1F - (float) Math.pow(1F - hoverLift, 3);
        int grow = Math.round((1F - (float) Math.pow(1F - focusScale, 3)) * 3F);
        int drawX = method_46426() - grow;
        int drawY = method_46427() - Math.round(eased * 5F) - grow;
        int drawWidth = field_22758 + grow * 2;
        int drawHeight = field_22759 + grow * 2;
        float silhouetteAlpha = entrance;
        float reveal = entrance;
        float drawAlpha = field_22765 * silhouetteAlpha;
        GlassRenderer.drawRevealingInteractive(graphics, drawX, drawY, drawWidth, drawHeight,
                drawAlpha, field_22763 && method_25367(), field_22763,
                mouseX, mouseY, hoverLift, reveal);
        SmoothLabel.draw(graphics, method_25369().getString(), drawX, drawY,
                drawWidth, drawHeight, field_22765 * entrance, field_22763, hoverLift);
    }
}
