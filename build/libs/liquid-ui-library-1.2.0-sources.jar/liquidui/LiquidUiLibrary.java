package liquidui;

import net.minecraft.class_2960;

public final class LiquidUiLibrary {
    public static final String MOD_ID = "liquid_ui_library";

    private LiquidUiLibrary() {
    }

    public static class_2960 id(String path) {
        return new class_2960(MOD_ID, path);
    }
}
